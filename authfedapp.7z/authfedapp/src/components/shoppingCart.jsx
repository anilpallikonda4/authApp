import React, { Component } from "react";
import CardItem from "./cardItem";
class ShoppingCart extends Component {
  state = {
    shoppingItems: [
      { id: 1, itemCount: 0, title: "item1", wishlist: false },
      { id: 2, itemCount: 0, title: "item2", wishlist: false },
      { id: 3, itemCount: 0, title: "item3", wishlist: false },
      { id: 4, itemCount: 0, title: "item4", wishlist: false }
    ]
  };
  handleDelete = itemId => {
    const shoppingItems = this.state.shoppingItems.filter(
      item => item.id !== itemId
    );
    this.setState({ shoppingItems });
  };
  handleLike = item => {
    const shoppingItems = [...this.state.shoppingItems];
    const index = shoppingItems.indexOf(item);
    shoppingItems[index] = { ...item };
    if (shoppingItems[index].wishlist === false)
      shoppingItems[index].wishlist = true;
    else shoppingItems[index].wishlist = false;
    console.log({ shoppingItems });
    this.setState({ shoppingItems });
  };
  handleIncrement = item => {
    const shoppingItems = [...this.state.shoppingItems];
    const index = shoppingItems.indexOf(item);
    shoppingItems[index] = { ...item };
    shoppingItems[index].itemCount++;
    this.setState({ shoppingItems });
  };
  handleDecrement = item => {
    const shoppingItems = [...this.state.shoppingItems];
    const index = shoppingItems.indexOf(item);
    shoppingItems[index] = { ...item };
    shoppingItems[index].itemCount--;
    this.setState({ shoppingItems });
  };
  handleReset = () => {
    const shoppingItems = this.state.shoppingItems.map(item => {
      item.itemCount = 0;
      item.wishlist = false;
      return item;
    });
    this.setState({ shoppingItems });
  };
  render() {
    const wishlistCount = this.state.shoppingItems.filter(item => item.wishlist)
      .length;
    const totalItemsCount = this.state.shoppingItems.length;
    const itemsInBag = this.state.shoppingItems.reduce(function(acc, item) {
      return acc + item.itemCount;
    }, 0);
    return (
      <div className="row">
        <div className="col-12">
          <button className="btn btn-primary" onClick={this.handleReset}>
            Reset App
          </button>
          <div className="cart-view">
            <span>
              {" "}
              {itemsInBag === 0 ? "" : "Items in Bag " + itemsInBag}{" "}
            </span>
            <span>
              {wishlistCount === 0 ? "" : "Wishlist Items " + wishlistCount}{" "}
            </span>
            <span>
              {totalItemsCount === 0
                ? ""
                : "Total Items Count " + totalItemsCount}{" "}
            </span>
          </div>
        </div>
        {this.state.shoppingItems.map(item => (
          <CardItem
            key={item.id}
            shoppingItem={item}
            onDelete={this.handleDelete}
            onIncrement={this.handleIncrement}
            onDecrement={this.handleDecrement}
            onLike={this.handleLike}
          />
        ))}
      </div>
    );
  }
}

export default ShoppingCart;
