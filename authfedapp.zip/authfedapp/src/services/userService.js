import http from "./httpService";
import { apiUrl } from "../config.json";

const apiEndpoint = apiUrl + "/users";

function userUrl(id) {
  return `${apiEndpoint}/${id}`;
}
export function getUsers() {
  return http.get(apiEndpoint);
}
export function getUserData(userId) {
  return http.get(userUrl(userId));
}
export function deleteUser(userId) {
  return http.delete(userUrl(userId));
}
export function register(user) {
  return http.post(apiEndpoint, {
    email: user.username,
    password: user.password,
    name: user.name
  });
}
export function saveUser(user) {
  if (user._id) {
    const body = {
      email: user.username,
      password: user.password,
      name: user.name
    };
    return http.put(userUrl(user._id), body);
  }
}
