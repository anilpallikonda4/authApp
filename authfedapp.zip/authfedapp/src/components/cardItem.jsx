import React, { Component } from "react";
import shopping from "./shopping.jpg";

class CardItem extends Component {
  render() {
    return (
      <React.Fragment>
        <div className="col-4">
          <div className="card">
            <img className="card-img-top" src={shopping} alt="Card image cap" />
            <div className="card-body">
              <h5 className="card-title">{this.props.shoppingItem.title}</h5>
              <div className="counter">
                <button
                  type="button"
                  className="btn btn-danger item-del"
                  onClick={() =>
                    this.props.onDelete(this.props.shoppingItem.id)
                  }
                >
                  <i className="fa fa-times" aria-hidden="true" />
                </button>

                <button
                  type="button"
                  className="btn btn-danger"
                  onClick={() =>
                    this.props.onDecrement(this.props.shoppingItem)
                  }
                  disabled={this.props.shoppingItem.itemCount === 0}
                >
                  <i className="fa fa-minus" aria-hidden="true" />
                </button>
                <span className="item-value">{this.formatCount()}</span>
                <button
                  type="button"
                  className="btn btn-primary"
                  onClick={() =>
                    this.props.onIncrement(this.props.shoppingItem)
                  }
                  disabled={this.props.shoppingItem.itemCount >= 5}
                >
                  <i className="fa fa-plus" aria-hidden="true" />
                </button>
                <button
                  type="button"
                  className="btn btn-light item-like"
                  onClick={() => this.props.onLike(this.props.shoppingItem)}
                >
                  <i
                    className={
                      this.props.shoppingItem.wishlist === false
                        ? "fa fa-heart-o"
                        : "fa fa-heart"
                    }
                    aria-hidden="true"
                  />
                </button>
              </div>
            </div>
          </div>
        </div>
      </React.Fragment>
    );
  }
  formatCount() {
    return this.props.shoppingItem.itemCount === 0 ? (
      <span>
        <i className="fa fa-shopping-basket" aria-hidden="true" />
      </span>
    ) : (
      this.props.shoppingItem.itemCount
    );
  }
}

export default CardItem;
