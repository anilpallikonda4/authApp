import React, { Component } from "react";
import { Route, Redirect, Switch } from "react-router-dom";
import { ToastContainer } from "react-toastify";
import Users from "./components/users";
import NotFound from "./components/notFound";
import NavBar from "./components/navBar";
import LoginForm from "./components/loginForm";
import RegisterForm from "./components/registerForm";
import ProtectedRoute from "./components/common/protectedRoute";
import LogOut from "./components/logOut";
import auth from "./services/authService";
import ShoppingCart from "./components/shoppingCart";
import "react-toastify/dist/ReactToastify.css";
import "./App.css";

class App extends Component {
  state = {};
  componentDidMount() {
    const user = auth.getCurrentUser();
    this.setState({ user });
  }
  render() {
    return (
      <React.Fragment>
        <ToastContainer />
        <NavBar user={this.state.user} />
        <main className="container">
          <Switch>
            <Route path="/register/:id" component={RegisterForm} />
            <Route path="/register" component={RegisterForm} />
            <Route path="/shoppingApp" component={ShoppingCart} />
            <Route path="/login" component={LoginForm} />
            <Route path="/logout" component={LogOut} />
            <ProtectedRoute path="/users" component={Users} />} />
            <Route path="/not-found" component={NotFound} />
            <Redirect from="/" exact to="/login" />
            <Redirect to="/not-found" />
          </Switch>
        </main>
      </React.Fragment>
    );
  }
}

export default App;
